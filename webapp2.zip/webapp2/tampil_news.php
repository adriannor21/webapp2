<?php
// tampil_news.php
require 'tampil_news_firebase.php'; // Memanggil fungsi untuk mengambil data dari Firebase

$newsList = fetch_news_from_firebase(); // Mendapatkan data berita dari Firebase
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>News List</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>News List</h2>
        <div class="row">
            <?php if (!empty($newsList)): ?>
                <?php foreach ($newsList as $key => $news): ?>
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <img src="<?php echo htmlspecialchars($news['image']); ?>" class="card-img-top" alt="News Image" style="max-height: 200px; object-fit: cover;">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($news['headline']); ?></h5>
                                <p class="card-text"><?php echo htmlspecialchars(substr($news['content'], 0, 100)) . '...'; ?></p>
                                <p class="card-text"><small class="text-muted"><?php echo htmlspecialchars($news['category']); ?></small></p>
                                <!-- Tombol Read More untuk membuka modal -->
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newsModal<?php echo $key; ?>">
                                    Read More
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Modal untuk menampilkan konten berita lengkap -->
                    <div class="modal fade" id="newsModal<?php echo $key; ?>" tabindex="-1" aria-labelledby="newsModalLabel<?php echo $key; ?>" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="newsModalLabel<?php echo $key; ?>"><?php echo htmlspecialchars($news['headline']); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <img src="<?php echo htmlspecialchars($news['image']); ?>" class="img-fluid mb-3" alt="News Image" style="max-height: 300px; object-fit: cover;">
                                    <p><?php echo nl2br(htmlspecialchars($news['content'])); ?></p>
                                    <p><small class="text-muted">Category: <?php echo htmlspecialchars($news['category']); ?></small></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No news available at the moment.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
