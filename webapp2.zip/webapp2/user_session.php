<?php
// user_session.php
session_start();

// Fungsi untuk menyimpan informasi pengguna ke dalam session
function setUserSession($uid, $email) {
    $_SESSION['uid'] = $uid;
    $_SESSION['email'] = $email;
}

// Fungsi untuk menghapus informasi session pengguna saat logout
function clearUserSession() {
    session_unset(); // Menghapus semua variabel session
    session_destroy(); // Mengakhiri session
}

// Fungsi untuk memeriksa apakah pengguna sudah login atau belum
function isUserLoggedIn() {
    return isset($_SESSION['uid']);
}

// Fungsi untuk mengambil UID pengguna yang login
function getUserUID() {
    return isset($_SESSION['uid']) ? $_SESSION['uid'] : null;
}

// Fungsi untuk mengambil email pengguna yang login
function getUserEmail() {
    return isset($_SESSION['email']) ? $_SESSION['email'] : null;
}
