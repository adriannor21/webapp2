<?php
// upload_news.php
session_start();
require 'firebase_credentials.php'; // Memuat Firebase credentials

use Kreait\Firebase\Factory;
use Kreait\Firebase\Exception\FirebaseException;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Mendapatkan data dari form
    $headline = isset($_POST['headlineTitle']) ? $_POST['headlineTitle'] : '';
    $content = isset($_POST['newsContent']) ? $_POST['newsContent'] : '';
    $category = isset($_POST['newsCategory']) ? $_POST['newsCategory'] : '';

    // Validasi input sebelum melanjutkan proses
    if ($headline && $content && $category) {
        try {
            // Inisialisasi Firebase menggunakan credentials JSON
            $firebase = (new Factory)
                ->withServiceAccount(__DIR__ . '/firebase_credentials.json')
                ->withDatabaseUri('https://webapp1-d7d74-default-rtdb.firebaseio.com');

            // Mendapatkan referensi ke Realtime Database dan Storage
            $database = $firebase->createDatabase();
            $storage = $firebase->createStorage();

            // Proses upload gambar ke Firebase Storage jika ada file yang diupload
            if (isset($_FILES['newsImage']) && $_FILES['newsImage']['error'] === UPLOAD_ERR_OK) {
                $imageTmpPath = $_FILES['newsImage']['tmp_name'];
                $imageName = uniqid() . '_' . basename($_FILES['newsImage']['name']);
                $bucket = $storage->getBucket(); // Ambil bucket storage
                
                // Upload gambar ke Firebase Storage
                $bucket->upload(
                    fopen($imageTmpPath, 'r'), // Baca file dari lokasi sementara
                    [
                        'name' => 'news_images/' . $imageName // Menyimpan di folder 'news_images'
                    ]
                );

                // Mendapatkan URL gambar yang di-upload
                $imageUrl = "https://firebasestorage.googleapis.com/v0/b/webapp1-d7d74.appspot.com/o/news_images%2F" . $imageName . "?alt=media";
            } else {
                $imageUrl = ''; // Jika tidak ada gambar, kosongkan URL
            }

            // Data yang akan dikirim ke Firebase
            $newsData = [
                'headline' => $headline,
                'content' => $content,
                'category' => $category,
                'image' => $imageUrl, // Menyimpan URL gambar ke database
                'timestamp' => time() // Menyimpan timestamp untuk catatan waktu berita
            ];

            // Menyimpan data ke Firebase (ke tabel 'news')
            $database->getReference('news')->push($newsData);

            // Redirect atau menampilkan pesan sukses
            $_SESSION['message'] = 'News added successfully!';
            header('Location: dashboard.php');
            exit;
        } catch (FirebaseException $e) {
            // Menangani error Firebase
            echo "Error: " . $e->getMessage();
        }
    } else {
        // Jika input tidak valid
        echo "Please fill all the fields.";
    }
} else {
    // Jika tidak ada request POST
    echo "Invalid request method.";
}
?>
