<?php
// dashboard.php
session_start();

// Memeriksa apakah pengguna sudah login atau belum
if (!isset($_SESSION['uid'])) {
    // Jika belum login, redirect ke halaman login
    header("Location: login.php");
    exit;
}

// Mendapatkan informasi pengguna dari session
$uid = $_SESSION['uid'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Dashboard</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <!-- Email User di sebelah kiri -->
            <span class="navbar-text text-white">
                <?php echo htmlspecialchars($email); ?>
            </span>
            
            <!-- Tombol Logout di sebelah kanan -->
            <div class="ms-auto">
                <a href="logout.php" class="btn btn-danger">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Konten Dashboard -->
    <div class="container mt-4">
        <!-- Button untuk menambahkan berita -->
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addNewsModal">
            Add News
        </button>

        <!-- Konten Berita (Memanggil tampil_news.php) -->
        <?php include 'tampil_news.php'; ?>
    </div>

    <!-- Modal untuk form tambah berita -->
    <div class="modal fade" id="addNewsModal" tabindex="-1" aria-labelledby="addNewsModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addNewsModalLabel">Add News</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Form untuk mengirim berita -->
                    <form action="upload_news.php" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="newsImage" class="form-label">Insert Image</label>
                            <input type="file" class="form-control" name="newsImage" id="newsImage">
                        </div>
                        <div class="mb-3">
                            <label for="headlineTitle" class="form-label">Headline Title</label>
                            <input type="text" class="form-control" name="headlineTitle" id="headlineTitle" placeholder="Enter headline title" required>
                        </div>
                        <div class="mb-3">
                            <label for="newsContent" class="form-label">News Content</label>
                            <textarea class="form-control" name="newsContent" id="newsContent" rows="4" placeholder="Enter news content" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="newsCategory" class="form-label">Category</label>
                            <select class="form-select" name="newsCategory" id="newsCategory" required>
                                <option selected disabled>Choose category</option>
                                <option value="Politics">Politics</option>
                                <option value="Technology">Technology</option>
                                <option value="Sports">Sports</option>
                                <option value="Entertainment">Entertainment</option>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
