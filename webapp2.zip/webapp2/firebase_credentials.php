<?php
// firebase_credentials.php
require __DIR__ . '/vendor/autoload.php'; // Path ke autoload Composer

use Kreait\Firebase\Factory;

function getFirebaseAuth() {
$serviceAccount = __DIR__ . '/firebase_credentials.json';


    // Buat instance Firebase Authentication
    $firebase = (new Factory)->withServiceAccount($serviceAccount);
    return $firebase->createAuth();
}
?>
