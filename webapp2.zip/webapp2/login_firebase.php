<?php
// login_firebase.php
require 'firebase_credentials.php'; // Memuat Firebase SDK dan credentials
require 'user_session.php'; // Memuat session handler

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil input dari form login
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validasi input sederhana
    if (empty($email) || empty($password)) {
        header("Location: login.php?error=Email and password are required.");
        exit;
    }

    try {
        // Mengakses Firebase Authentication
        $auth = getFirebaseAuth();

        // Login pengguna dengan email dan password
        $signInResult = $auth->signInWithEmailAndPassword($email, $password);

        // Mendapatkan UID pengguna dari hasil login
        $uid = $signInResult->firebaseUserId();

        // Menyimpan informasi pengguna ke dalam session
        setUserSession($uid, $email);

        // Redirect ke dashboard setelah login berhasil
        header("Location: dashboard.php");
        exit;
    } catch (\Kreait\Firebase\Exception\Auth\AuthError $e) {
        header("Location: login.php?error=Error logging in: " . urlencode($e->getMessage()));
        exit;
    } catch (\Kreait\Firebase\Exception\FirebaseException $e) {
        header("Location: login.php?error=Firebase error: " . urlencode($e->getMessage()));
        exit;
    }
} else {
    header("Location: login.php?error=Invalid request method.");
    exit;
}
