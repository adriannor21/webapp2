<?php
// register_firebase.php
require 'firebase_credentials.php'; // Memuat Firebase SDK dan credentials

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil input dari form
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validasi input sederhana
    if (empty($name) || empty($email) || empty($password)) {
        echo "All fields are required.";
        exit;
    }

    try {
        // Mengakses Firebase Authentication melalui fungsi getFirebaseAuth()
        $auth = getFirebaseAuth();

        // Membuat user baru di Firebase Auth
        $userProperties = [
            'email' => $email,
            'password' => $password,
            'displayName' => $name,
        ];

        // Mendaftarkan pengguna
        $createdUser = $auth->createUser($userProperties);

        // Jika berhasil, arahkan ke halaman lain atau tampilkan pesan
        echo "User registered successfully! Welcome, " . $createdUser->displayName;

        // Redirect ke dashboard atau login
        header("Location: login.php");
    } catch (\Kreait\Firebase\Exception\AuthException $e) {
        echo "Error registering user: " . $e->getMessage();
    } catch (\Kreait\Firebase\Exception\FirebaseException $e) {
        echo "Firebase error: " . $e->getMessage();
    }
} else {
    echo "Invalid request method.";
}
?>
