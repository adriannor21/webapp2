<?php
// tampil_news_firebase.php
require 'firebase_credentials.php'; // Memuat Firebase credentials

use Kreait\Firebase\Factory;
use Kreait\Firebase\Exception\FirebaseException;

function fetch_news_from_firebase() {
    try {
        // Inisialisasi Firebase menggunakan credentials JSON
        $firebase = (new Factory)
            ->withServiceAccount(__DIR__ . '/firebase_credentials.json')
            ->withDatabaseUri('https://webapp1-d7d74-default-rtdb.firebaseio.com');

        // Mendapatkan referensi ke Realtime Database
        $database = $firebase->createDatabase();
        
        // Mendapatkan data dari node "news"
        $newsSnapshot = $database->getReference('news')->getSnapshot();
        $newsData = $newsSnapshot->getValue();
        
        // Kembalikan data berita dalam bentuk array
        if ($newsData) {
            return $newsData;
        } else {
            return [];
        }
    } catch (FirebaseException $e) {
        echo "Error: " . $e->getMessage();
        return [];
    }
}
?>
